#program python untuk menentukan sebuah bilangan termasuk bilangan positif atau negatif
angka = int(input("masukkan bilangan :"))
if angka >= 0:
    print("bilangan postif")
else:
    if angka < 0:
        print("bilangan negatif")