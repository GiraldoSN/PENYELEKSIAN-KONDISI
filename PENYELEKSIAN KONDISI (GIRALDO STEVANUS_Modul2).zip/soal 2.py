#Meminta input dua buah angka dari user dan menempatkannya pada variable masing-masing.Jika angka pertama lebih besar dari angka kedua, tukar isi kedua variable.Tampilkan nilai kedua variable ke layar
a = int(input("masukkan bilangan pertama:"))
b = int(input("masukkkan bilangan kedua :"))
if a > b:
    print (b)
    print(a)
else :
    print (a)
    print(b)